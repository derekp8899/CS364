//Derek Popowski
//derek.a.popowski@und.edu
//CSCI 364
//1-8-2019

public class hello{
    public static void main(String args[]){
	
	System.out.println("Hello World!");
	
    }
}
